# TCL Minimal TV Launcher

Minimal, remote-friendly Android TV home app for TCL R51MT05 / Android TV.

## Features in this starter project
- Large 24-hour clock and date
- Minimal dark gradient background with very slow, low-intensity movement
- Remote-focusable dock
- Lists installed TV/launcher apps and launches them
- Opens Android Settings
- Weather tile opens a web search (requires a browser and internet)
- Declares itself as a HOME activity but does not disable or replace the stock launcher

## Important limitations
- This is starter source, not tested on the exact TCL firmware.
- Android TV firmware may restrict visibility/launching of some packages.
- Weather currently opens a web search; it does not display a live forecast inside the launcher.
- The APK is not included because it must be compiled/signed by Android build tools.

## Build on an Android phone (cloud build)
1. Create a GitHub account and a new repository, e.g. `TCLMinimalLauncher`.
2. Upload the project files/folders in this ZIP to the repository root.
3. Add the workflow file from `.github/workflows/build-apk.yml` (included).
4. Open the repository's **Actions** tab and run **Build Android APK**.
5. Download `app-debug.apk` from the workflow artifact.
6. Transfer APK to the TV using Send Files to TV, then install it.
7. Open the app manually first. Do not disable Google TV Home.

## Build locally in AndroidIDE
1. Install AndroidIDE from its official source and open/import this project folder.
2. Allow it to install required Gradle/Android SDK components.
3. Run the `assembleDebug` Gradle task.
4. APK path: `app/build/outputs/apk/debug/app-debug.apk`.

Build requirements: Android Gradle Plugin 8.7.3, JDK 17, Android SDK platform 35.

## Updated v1.1: Vietnamese lunar calendar + wallpaper settings
- Large lunar date line (Vietnam time zone UTC+7), with lunar day/month and Can-Chi year.
- New **Hình nền** dock item: choose an image through Android's document picker (TV storage or a connected USB, if the TV exposes it), or restore the default background.
- Wallpaper URI is saved in private app preferences and read permission is persisted where the TV's document provider supports it.
- No root, no ADB requirement, and no disabling the stock Google TV launcher.

### Importing a photo from a phone
The launcher does not directly browse another phone over Wi-Fi. Transfer the photo to the TV first using a trusted transfer app such as Send Files to TV, or copy it to a USB drive, then select it from **Hình nền**. Exact picker and USB behavior depends on the TV firmware and installed file/document provider.

### Notes / limitations
- Lunar conversion is implemented locally for Vietnam UTC+7 and does not require internet. Please verify important festival dates against a trusted Vietnamese calendar before relying on it; this is a starter implementation and has not been tested on the target TV.
- Background images are decoded at reduced resolution to limit memory use. Very large images may still be slow or unsupported on older TV firmware.
- Choosing a wallpaper may fail if the firmware does not provide an image/document picker or if a USB file provider is unavailable.
- The stock launcher remains installed and enabled. If Android asks which Home app to use, choose this launcher only for testing; the stock launcher can still be selected again in system settings.
