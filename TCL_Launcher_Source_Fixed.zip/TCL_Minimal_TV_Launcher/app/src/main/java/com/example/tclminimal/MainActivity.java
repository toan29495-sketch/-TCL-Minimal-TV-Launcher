package com.example.tclminimal;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.content.SharedPreferences;
import android.os.Build;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root, dock;
    private TextView clock, date, lunar, weather;
    private SharedPreferences prefs;
    private static final int PICK_WALLPAPER = 731;
    private final int white = Color.rgb(245,247,255);
    private final int muted = Color.rgb(173,183,205);
    private final int blue = Color.rgb(115,174,255);
    private final HandlerTick tick = new HandlerTick();
    private int focusIndex = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        prefs = getSharedPreferences("launcher_settings", MODE_PRIVATE);
        buildUi();
        applySavedWallpaper();
        updateClock();
        tick.start();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(48), dp(28), dp(48), dp(34));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackground(new SoftBackground());
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(top, new LinearLayout.LayoutParams(-1, 0, 1f));

        clock = new TextView(this);
        clock.setTextColor(white);
        clock.setTextSize(64);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clock.setGravity(Gravity.CENTER);
        top.addView(clock);

        date = new TextView(this);
        date.setTextColor(muted);
        date.setTextSize(18);
        date.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dateLp = new LinearLayout.LayoutParams(-2, -2);
        dateLp.topMargin = dp(3);
        top.addView(date, dateLp);

        lunar = new TextView(this);
        lunar.setTextColor(Color.rgb(255, 211, 132));
        lunar.setTextSize(23);
        lunar.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        lunar.setGravity(Gravity.CENTER);
        lunar.setShadowLayer(dp(8), 0, dp(2), 0xAA000000);
        LinearLayout.LayoutParams lunarLp = new LinearLayout.LayoutParams(-2, -2);
        lunarLp.topMargin = dp(10);
        top.addView(lunar, lunarLp);

        weather = new TextView(this);
        weather.setText("THỜI TIẾT  ·  Chạm OK để xem dự báo");
        weather.setTextColor(white);
        weather.setTextSize(15);
        weather.setGravity(Gravity.CENTER);
        weather.setPadding(dp(20), dp(10), dp(20), dp(10));
        weather.setBackground(glass(0x1FFFFFFF, 0x33FFFFFF, 22));
        weather.setFocusable(true);
        weather.setOnClickListener(v -> openWeather());
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-2, -2);
        wlp.topMargin = dp(24);
        top.addView(weather, wlp);

        TextView caption = new TextView(this);
        caption.setText("MỌI THỨ BẠN CẦN, KHÔNG GÌ THỪA");
        caption.setTextColor(0x99FFFFFF);
        caption.setTextSize(11);
        caption.setLetterSpacing(0.16f);
        caption.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
        clp.topMargin = dp(20);
        top.addView(caption, clp);

        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(10), dp(10), dp(10), dp(10));
        dock.setBackground(glass(0x26FFFFFF, 0x44FFFFFF, 28));
        root.addView(dock, new LinearLayout.LayoutParams(-1, dp(100)));
        addDockItem("Ứng dụng", "▦", this::showApps);
        addDockItem("Cài đặt", "⚙", this::openSettings);
        addDockItem("Thời tiết", "☼", this::openWeather);
        addDockItem("Hình nền", "▧", this::showWallpaperOptions);
        addDockItem("Tải lại", "↻", () -> { updateClock(); applySavedWallpaper(); });
        weather.requestFocus();
    }

    private void addDockItem(String label, String symbol, Runnable action) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setFocusable(true);
        item.setClickable(true);
        item.setPadding(dp(18), dp(7), dp(18), dp(7));
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextSize(27);
        icon.setTextColor(white);
        icon.setGravity(Gravity.CENTER);
        item.addView(icon);
        TextView name = new TextView(this);
        name.setText(label);
        name.setTextSize(12);
        name.setTextColor(muted);
        name.setGravity(Gravity.CENTER);
        item.addView(name);
        item.setBackground(glass(0x12FFFFFF, 0x00FFFFFF, 18));
        item.setOnFocusChangeListener((v, hasFocus) -> {
            v.setScaleX(hasFocus ? 1.07f : 1f);
            v.setScaleY(hasFocus ? 1.07f : 1f);
            v.setBackground(glass(hasFocus ? 0x40FFFFFF : 0x12FFFFFF,
                                  hasFocus ? 0xAAFFFFFF : 0x00FFFFFF, 18));
            name.setTextColor(hasFocus ? white : muted);
        });
        item.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
        lp.setMargins(dp(5), 0, dp(5), 0);
        dock.addView(item, lp);
    }

    private void updateClock() {
        Date now = new Date();
        clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
        date.setText(new SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("vi", "VN")).format(now));
        int[] lunarDate = LunarCalendar.convert(now.getDate(), now.getMonth() + 1, now.getYear() + 1900, 7.0);
        String[] can = {"Giáp","Ất","Bính","Đinh","Mậu","Kỷ","Canh","Tân","Nhâm","Quý"};
        String[] chi = {"Tý","Sửu","Dần","Mão","Thìn","Tỵ","Ngọ","Mùi","Thân","Dậu","Tuất","Hợi"};
        int year = now.getYear() + 1900;
        String lunarText = lunarDate[0] + "/" + lunarDate[1] + " ÂM LỊCH  ·  Năm " + can[(year + 6) % 10] + " " + chi[(year + 8) % 12];
        if (lunarDate[0] == 1) lunarText += "  ·  Mùng một";
        if (lunarDate[0] == 15) lunarText += "  ·  Rằm";
        lunar.setText(lunarText);
    }

    private void showApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(24), dp(14), dp(24), dp(14));
        int count = 0;
        for (ApplicationInfo ai : apps) {
            Intent launch = pm.getLeanbackLaunchIntentForPackage(ai.packageName);
            if (launch == null) launch = pm.getLaunchIntentForPackage(ai.packageName);
            if (launch == null || ai.packageName.equals(getPackageName())) continue;
            String label;
            try { label = pm.getApplicationLabel(ai).toString(); }
            catch (Exception e) { label = ai.packageName; }
            TextView row = new TextView(this);
            row.setText("  " + label);
            row.setTextSize(20);
            row.setTextColor(white);
            row.setFocusable(true);
            row.setPadding(dp(18), dp(12), dp(18), dp(12));
            row.setBackground(glass(0x1FFFFFFF, 0x22FFFFFF, 14));
            final Intent finalLaunch = launch;
            row.setOnClickListener(v -> {
                try { startActivity(finalLaunch); }
                catch (Exception e) { Toast.makeText(this, "Không mở được ứng dụng", Toast.LENGTH_SHORT).show(); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(7);
            list.addView(row, lp);
            count++;
        }
        if (count == 0) {
            TextView empty = new TextView(this);
            empty.setText("Không tìm thấy ứng dụng tương thích với TV.");
            empty.setTextColor(white);
            list.addView(empty);
        }
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Ứng dụng")
            .setView(list)
            .setNegativeButton("Đóng", null)
            .show();
    }

    private void showWallpaperOptions() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Hình nền")
            .setItems(new String[]{"Chọn ảnh từ TV / USB", "Dùng hình nền mặc định"}, (dialog, which) -> {
                if (which == 0) pickWallpaper();
                else { prefs.edit().remove("wallpaper_uri").apply(); root.setBackground(new SoftBackground()); }
            }).show();
    }

    private void pickWallpaper() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_WALLPAPER); }
        catch (Exception e) { Toast.makeText(this, "TV không mở được trình chọn ảnh. Hãy thử ứng dụng Ảnh hoặc USB.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_WALLPAPER && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                prefs.edit().putString("wallpaper_uri", uri.toString()).apply();
                applySavedWallpaper();
            } catch (Exception e) { Toast.makeText(this, "Không lưu được quyền đọc ảnh này. Hãy chọn ảnh khác.", Toast.LENGTH_LONG).show(); }
        }
    }

    private void applySavedWallpaper() {
        if (root == null || prefs == null) return;
        String saved = prefs.getString("wallpaper_uri", null);
        if (saved == null) { root.setBackground(new SoftBackground()); return; }
        try {
            Uri uri = Uri.parse(saved);
            android.graphics.BitmapFactory.Options opts = new android.graphics.BitmapFactory.Options();
            opts.inSampleSize = 2;
            android.graphics.Bitmap bitmap;
            try (java.io.InputStream in = getContentResolver().openInputStream(uri)) { bitmap = BitmapFactory.decodeStream(in, null, opts); }
            if (bitmap != null) {
                BitmapDrawable bg = new BitmapDrawable(getResources(), bitmap);
                bg.setGravity(Gravity.FILL);
                root.setBackground(bg);
            } else root.setBackground(new SoftBackground());
        } catch (Exception e) { root.setBackground(new SoftBackground()); }
    }

    private void openSettings() {
        try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        catch (ActivityNotFoundException e) {
            try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); }
            catch (Exception ignored) { Toast.makeText(this, "Không mở được cài đặt", Toast.LENGTH_SHORT).show(); }
        }
    }

    private void openWeather() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=th%E1%BB%9Di+ti%E1%BA%BFt+h%C3%B4m+nay"));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "TV chưa có trình duyệt tương thích", Toast.LENGTH_LONG).show();
        }
    }

    private GradientDrawable glass(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) { showApps(); return true; }
        if (keyCode == KeyEvent.KEYCODE_BACK) { return super.onKeyDown(keyCode, event); }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onDestroy() {
        tick.stop();
        super.onDestroy();
    }

    private class HandlerTick implements Runnable {
        private final android.os.Handler handler = new android.os.Handler();
        void start() { handler.post(this); }
        void stop() { handler.removeCallbacks(this); }
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 30000);
        }
    }

    private class SoftBackground extends Drawable {
        private final android.graphics.Paint p = new android.graphics.Paint(3);
        private long start = System.currentTimeMillis();
        SoftBackground() { super(); }
        @Override public void draw(android.graphics.Canvas c) {
            android.graphics.Rect bounds = getBounds();
            float w=bounds.width(), h=bounds.height();
            c.drawColor(Color.rgb(8,12,25));
            float phase = ((System.currentTimeMillis()-start)%24000L)/24000f;
            float x = w*(0.25f + 0.12f*(float)Math.sin(phase*6.283));
            float y = h*(0.32f + 0.08f*(float)Math.cos(phase*6.283));
            p.setShader(new android.graphics.RadialGradient(x,y,Math.max(w,h)*0.72f,
                new int[]{0x553D6DAA,0x222A3F6F,0x00080C19}, null, android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);
            p.setShader(null);
        }
        @Override public void setAlpha(int alpha) { p.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { p.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.OPAQUE; }
    }

    // Vietnamese lunar-calendar conversion (UTC+7), adapted from the widely used Ho Ngoc Duc algorithm.
    private static class LunarCalendar {
        static int[] convert(int dd, int mm, int yy, double timeZone) {
            int dayNumber = jdFromDate(dd, mm, yy);
            int k = (int)Math.floor((dayNumber - 2415021.076998695) / 29.530588853);
            int monthStart = getNewMoonDay(k + 1, timeZone);
            if (monthStart > dayNumber) monthStart = getNewMoonDay(k, timeZone);
            int a11 = getLunarMonth11(yy, timeZone);
            int b11 = a11;
            int lunarYear;
            if (a11 >= monthStart) { lunarYear = yy; a11 = getLunarMonth11(yy - 1, timeZone); }
            else { lunarYear = yy + 1; b11 = getLunarMonth11(yy + 1, timeZone); }
            int lunarDay = dayNumber - monthStart + 1;
            int diff = (int)Math.floor((monthStart - a11) / 29.0);
            int lunarMonth = diff + 11;
            if (b11 - a11 > 365) {
                int leapMonthDiff = getLeapMonthOffset(a11, timeZone);
                if (diff >= leapMonthDiff) lunarMonth = diff + 10;
            }
            if (lunarMonth > 12) lunarMonth -= 12;
            if (lunarMonth >= 11 && diff < 4) lunarYear--;
            return new int[]{lunarDay, lunarMonth, lunarYear};
        }
        private static int jdFromDate(int dd, int mm, int yy) {
            int a=(14-mm)/12, y=yy+4800-a, m=mm+12*a-3;
            int jd=dd+(153*m+2)/5+365*y+y/4-y/100+y/400-32045;
            if (jd < 2299161) jd=dd+(153*m+2)/5+365*y+y/4-32083;
            return jd;
        }
        private static double newMoon(int k) {
            double T=k/1236.85, T2=T*T, T3=T2*T, dr=Math.PI/180;
            double jd1=2415020.75933+29.53058868*k+0.0001178*T2-0.000000155*T3;
            jd1 += 0.00033*Math.sin((166.56+132.87*T-0.009173*T2)*dr);
            double M=359.2242+29.10535608*k-0.0000333*T2-0.00000347*T3;
            double Mpr=306.0253+385.81691806*k+0.0107306*T2+0.00001236*T3;
            double F=21.2964+390.67050646*k-0.0016528*T2-0.00000239*T3;
            double C=(0.1734-0.000393*T)*Math.sin(M*dr)+0.0021*Math.sin(2*M*dr)-0.4068*Math.sin(Mpr*dr)+0.0161*Math.sin(2*Mpr*dr)-0.0004*Math.sin(3*Mpr*dr)+0.0104*Math.sin(2*F*dr)-0.0051*Math.sin((M+Mpr)*dr)-0.0074*Math.sin((M-Mpr)*dr)+0.0004*Math.sin((2*F+M)*dr)-0.0004*Math.sin((2*F-M)*dr)-0.0006*Math.sin((2*F+Mpr)*dr)+0.0010*Math.sin((2*F-Mpr)*dr)+0.0005*Math.sin((2*Mpr+M)*dr);
            double deltaT=T < -11 ? 0.001+0.000839*T+0.0002261*T2-0.00000845*T3-0.000000081*T*T3 : -0.000278+0.000265*T+0.000262*T2;
            return jd1+C-deltaT;
        }
        private static int getNewMoonDay(int k,double tz) { return (int)Math.floor(newMoon(k)+0.5+tz/24); }
        private static double sunLongitude(double jdn) {
            double T=(jdn-2451545.0)/36525, T2=T*T, dr=Math.PI/180;
            double M=357.52910+35999.05030*T-0.0001559*T2-0.00000048*T*T2;
            double L0=280.46645+36000.76983*T+0.0003032*T2;
            double DL=(1.914600-0.004817*T-0.000014*T2)*Math.sin(dr*M)+(0.019993-0.000101*T)*Math.sin(2*dr*M)+0.000290*Math.sin(3*dr*M);
            double L=(L0+DL)*dr; L-=Math.PI*2*Math.floor(L/(Math.PI*2)); return L;
        }
        private static int getSunLongitude(int dayNumber,double tz) { return (int)Math.floor(sunLongitude(dayNumber-0.5-tz/24)/Math.PI*6); }
        private static int getLunarMonth11(int yy,double tz) {
            int off=jdFromDate(31,12,yy)-2415021, k=(int)Math.floor(off/29.530588853), nm=getNewMoonDay(k,tz);
            if (getSunLongitude(nm,tz)>=9) nm=getNewMoonDay(k-1,tz);
            return nm;
        }
        private static int getLeapMonthOffset(int a11,double tz) {
            int k=(int)Math.floor((a11-2415021.076998695)/29.530588853), last=0, i=1, arc=getSunLongitude(getNewMoonDay(k+i,tz),tz);
            do { last=arc; i++; arc=getSunLongitude(getNewMoonDay(k+i,tz),tz); } while (arc!=last && i<14);
            return i-1;
        }
    }

}
