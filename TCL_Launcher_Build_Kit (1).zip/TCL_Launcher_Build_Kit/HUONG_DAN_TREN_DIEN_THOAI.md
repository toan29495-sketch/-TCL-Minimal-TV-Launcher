# Hướng dẫn tạo APK launcher TCL bằng điện thoại Android

## Những gì có trong bộ này
- `TCL_Minimal_TV_Launcher_Source.zip`: mã nguồn dự án launcher.
- `build-apk.yml`: quy trình GitHub Actions để biên dịch APK trên máy chủ GitHub.

**Lưu ý:** Bộ này chưa chứa APK đã biên dịch. APK chỉ có sau khi GitHub Actions chạy thành công. Mã nguồn là bản khởi đầu, chưa được thử nghiệm trực tiếp trên TCL R51MT05.

## Phần A — Tạo repository GitHub
1. Mở trình duyệt trên điện thoại, vào https://github.com và đăng nhập/tạo tài khoản.
2. Nhấn dấu `+` hoặc mở https://github.com/new.
3. Đặt tên repository: `TCLMinimalLauncher`.
4. Chọn `Public` hoặc `Private` tùy ý; chọn `Add a README file` nếu giao diện có lựa chọn này.
5. Nhấn `Create repository`.

## Phần B — Đưa ZIP mã nguồn lên repository
1. Mở repository vừa tạo.
2. Chọn `Add file` → `Upload files` (có thể cần bật chế độ trang web cho máy tính trong trình duyệt).
3. Chọn file `TCL_Minimal_TV_Launcher_Source.zip` từ thư mục tải xuống của điện thoại. Nếu bộ hướng dẫn này được tải về dưới dạng ZIP, hãy giải nén nó trước bằng trình quản lý tệp để lấy file ZIP mã nguồn bên trong.
4. Nhấn `Commit changes`.

**Quan trọng:** Chỉ tải lên `TCL_Minimal_TV_Launcher_Source.zip`; không tải nguyên bộ hướng dẫn ZIP lên thay cho file mã nguồn bên trong.

## Phần C — Tạo workflow biên dịch
1. Trong repository, nhấn `Add file` → `Create new file`.
2. Ở ô tên file, nhập chính xác: `.github/workflows/build-apk.yml`.
3. Mở file `build-apk.yml` trong bộ hướng dẫn đã giải nén, sao chép toàn bộ nội dung và dán vào trình soạn thảo GitHub.
4. Nhấn `Commit changes`.

## Phần D — Chạy biên dịch
1. Mở tab `Actions` của repository.
2. Chọn workflow `Build TCL Minimal TV Launcher APK`.
3. Nhấn `Run workflow` → `Run workflow`.
4. Chờ công việc hoàn tất. Nếu màu xanh lá/hiện `Success`, mở lần chạy đó.
5. Kéo xuống `Artifacts`, tải `TCL-Minimal-TV-Launcher-APK` về điện thoại.
6. Giải nén artifact đã tải để lấy `app-debug.apk`.

Nếu workflow báo lỗi màu đỏ, mở lần chạy → bước bị lỗi → sao chép phần log lỗi gửi lại để được hướng dẫn sửa. Không chia sẻ mật khẩu, mã xác minh hoặc token GitHub.

## Phần E — Cài lên TV an toàn
1. Chuyển `app-debug.apk` sang TV bằng USB hoặc ứng dụng chuyển tệp đáng tin cậy.
2. Cho phép cài ứng dụng từ nguồn này nếu Android TV yêu cầu, rồi cài APK.
3. Mở launcher mới thủ công để thử trước.
4. Nếu TV hỏi chọn ứng dụng Home, có thể chọn launcher mới để thử, nhưng **không chọn tùy chọn luôn luôn/không bao giờ nếu chưa kiểm tra**.
5. Không gỡ, vô hiệu hóa hay thay thế Google TV Home. Nếu có lỗi, vào Cài đặt → Ứng dụng → Ứng dụng mặc định/Home (tên mục tùy firmware) để chọn lại launcher gốc.

## Tính năng và giới hạn hiện tại
- Đồng hồ, ngày dương lịch và lịch âm Việt Nam (thuật toán cục bộ, cần kiểm tra thực tế).
- Giao diện tối giản và các nút thao tác bằng remote.
- Chọn hình nền qua bộ chọn tệp của Android nếu firmware cung cấp; có thể chọn ảnh trên USB nếu TV hiển thị USB trong bộ chọn.
- Ô thời tiết hiện mở tìm kiếm web, chưa phải dự báo thời tiết trực tiếp tích hợp.
- Không cần root/ADB. Launcher Google TV gốc vẫn được giữ lại.
- Chưa kiểm chứng trên đúng firmware TV của bạn; việc biên dịch thành công không đảm bảo mọi tính năng hoạt động hoàn hảo trên TV.
